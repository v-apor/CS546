export const mongoConfig = {
    serverUrl: "mongodb://localhost:27017/",
    database: "Apoorv_Chandrakar_lab4",
};
